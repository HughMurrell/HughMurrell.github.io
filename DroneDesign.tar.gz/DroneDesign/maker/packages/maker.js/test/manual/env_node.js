var makerjs = require("../index");
console.log(makerjs.environment);
